# Eksperimen Operasi Dasar Sinyal dan Citra

## Identitas Mahasiswa
* **Nama:** Muhammad Aditya Azka Azkia
* **Mata Kuliah:** Pengolahan Sinyal Digital

## Deskripsi Singkat Project
Project ini berisi eksperimen implementasi operasi dasar pada sinyal 1D (diskrit) dan citra 2D meliputi penjumlahan, penggeseran, serta amplifikasi. Selain itu, dilakukan pengujian matematis dan visual untuk membuktikan sifat linieritas sistem (Homogenitas & Additivitas).

## Library yang Digunakan
* NumPy
* Matplotlib
* OpenCV (cv2)

## Cara Menjalankan Notebook
1. Clone repositori ini ke lokal atau buka lewat Google Colab.
2. Pastikan dependensi terinstall: pip install -r requirements.txt
3. Jalankan file notebook/operasi_sinyal_citra.ipynb.

## Struktur Folder Project
operasi-dasar-sinyal-citra/
|-- notebook/
|   └── operasi_sinyal_citra.ipynb
|-- images/
|   └── citra_yang_digunakan.jpg
|-- report/
|   └── laporan.pdf
|-- README.md
└── requirements.txt